<?php
    $con = new mysqli("localhost","root","","demo");

    $data = file_get_contents('php://input');

    $dt = json_decode($data);
 
    $emp_name = $dt->Name;
    $emp_add = $dt->Address;
    
    $query = "insert into tblemp(Name,Address)values('$emp_name','$emp_add')";

    $con-> query($query);

    echo "success"

?>
