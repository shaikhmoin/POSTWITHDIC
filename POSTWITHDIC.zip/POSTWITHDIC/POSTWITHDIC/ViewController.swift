//
//  ViewController.swift
//  POSTWITHDIC
//
//  Created by MACOS on 6/14/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var final = [Any]()
    
    @IBOutlet var txtname: UITextField!
    @IBOutlet var txtadd: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let str = String("http://localhost/test/select.php")
        
        let url = URL(string: str!)
        
        var request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
            
            //let str1 = String(data: data!, encoding: String.Encoding.utf8)
            //print(str1 ?? "")
            DispatchQueue.main.sync {
                do
                {
                   let dic = try JSONSerialization.jsonObject(with: data!, options: []) as! [Any]
                   
                    for item in dic
                    {
                        self.final.append(item)
                        print(self.final)
                    }
                }
                catch
                {
                    
                }
            }
            
        })
        datatask.resume()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func btnInsert(_ sender: Any) {
        
        var dic : [String : String] = [:]
        
        dic["Name"] = txtname.text
        dic["Address"] = txtadd.text

        do
        {
            var dt = try JSONSerialization.data(withJSONObject: dic, options: [])
            
            let len = dt.count
            
            let str = String("http://localhost/test/index.php")
            
            let url = URL(string: str!)
            
            var request = URLRequest(url: url!)
            
            request.addValue(String(len), forHTTPHeaderField: "Content-Length")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            request.addValue("application/json", forHTTPHeaderField: "Accept")
            request.addValue("json", forHTTPHeaderField: "Data-Type")
            
            request.httpBody = dt
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            
            let datatask = session.dataTask(with: request, completionHandler: {(data,res,err) in
                
                let str1 = String(data: data!, encoding: String.Encoding.utf8)
                print(str1 ?? "")
                
            })
            
            let nav = self.storyboard?.instantiateViewController(withIdentifier: "next") as! First
            nav.st = final
            self.navigationController?.pushViewController(nav, animated: true)
            datatask.resume()

        }
        catch
        {
            
        }
        
    }


}

